# Security Notes

## Secrets
No Facebook access token is hardcoded in this repository. A token entered in the app is stored under the app's Keychain service and sent to Meta only as an HTTPS Bearer authorization header.

## Local data
- Secret token: iOS Keychain, `kSecAttrAccessibleWhenUnlockedThisDeviceOnly`, no synchronizable/iCloud item.
- Schedule history/captions: protected Application Support file using Complete File Protection.
- Page ID and Graph API version: non-secret preferences stored in UserDefaults.

## Network
All app API endpoints are constructed under `https://graph.facebook.com/<version>/...`. The network session is ephemeral and persistent cookie/cache storage is disabled.

## Scope
This hardening protects against common accidental leakage (URLs, source code, ordinary caches, UserDefaults, logs). It cannot guarantee secrecy on a jailbroken/compromised device, a maliciously modified IPA, or a compromised Meta account/token.
