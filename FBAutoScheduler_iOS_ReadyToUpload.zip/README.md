# FB Auto Scheduler for iPhone — Security Hardened v2

A SwiftUI iOS app that schedules Facebook Page posts through the Meta Graph API. Once Meta accepts the future `scheduled_publish_time`, the iPhone does not need to remain open for the post to publish.

## v2 security changes
- Page access token is sent only in the HTTPS `Authorization: Bearer ...` header.
- The token is never placed in a URL query string, form body, multipart body, log, history record, or repository file.
- Token is stored in iOS Keychain with `WhenUnlockedThisDeviceOnly` protection and is excluded from iCloud Keychain sync.
- Graph requests use an ephemeral `URLSession` with no persistent cookies and no URL cache.
- Requests add `Cache-Control: no-store` and `Pragma: no-cache`.
- Graph API version input is validated before building a URL.
- Raw unexpected server response bodies are not displayed, reducing accidental exposure of sensitive request context.
- Schedule history/captions are moved out of `UserDefaults` into an Application Support file protected with iOS Complete File Protection.
- Existing v1 history is migrated once and removed from `UserDefaults`.

## Features
- Facebook Page ID + Page Access Token settings
- Test Page connection
- Schedule text-only posts
- Schedule one photo + caption
- Batch schedule up to 30 photos
- First-post time + configurable minute gap (for example every 40 minutes)
- One caption for all, or matching captions separated by `---`
- Exact date/time picker
- Protected local success/failure history
- GitHub Actions workflow that builds an unsigned IPA for sideloading/resigning

## Important Meta setup
You need a Facebook Page access token allowed to manage posts for the Page. Meta permissions and App Review requirements depend on the Meta app and use case. A Page publishing setup commonly needs `pages_manage_posts`, plus other Page-related permissions depending on how the token is obtained.

Meta retires Graph API versions over time. The Graph API version remains editable in Settings; use a currently supported `vXX.0` version for your Meta app.

**Never commit or paste a real Page token into GitHub, source files, issue trackers, screenshots, chats, or build logs. Enter it only inside the installed app.**

## Build on GitHub (no Mac required)
1. Create a new private GitHub repository.
2. Upload this project, preserving `.github/workflows/build.yml`.
3. Open **Actions → Build iOS IPA → Run workflow**.
4. Download the `FBAutoScheduler-unsigned` build artifact.
5. Resign/sideload it using your normal iPhone sideloading method.

For best security, keep the repository private and build from this source yourself instead of installing an IPA modified by an unknown third party.

## First run
1. Open **Settings**.
2. Enter your numeric Facebook **Page ID**.
3. Paste your **Page Access Token**.
4. Enter a supported Graph API version such as `v26.0` if appropriate for your Meta app.
5. Tap **Test Page Connection**.
6. Open **Schedule** or **Batch**, choose media/captions, set the future time, and submit.

## What v2 does not do
- It does not upload the token anywhere except Meta Graph API requests.
- It has no analytics, ads, tracking SDK, custom backend, or telemetry.
- It does not make a Page token impossible to steal on a compromised/jailbroken device.
- It does not replace Meta's permission, token-expiry, App Review, or account-security requirements.

## Recommended account hygiene
- Use the minimum Page permissions needed.
- Revoke/rotate a token immediately if it is ever exposed.
- Do not distribute a build containing a hardcoded token; this project contains none.
- Prefer a private GitHub repository for your own scheduler.
