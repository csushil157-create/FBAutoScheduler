import Foundation

struct FacebookAPI {
    let pageID: String
    let pageToken: String
    let graphVersion: String

    struct PageInfo: Decodable {
        let id: String
        let name: String
    }

    struct PublishResponse: Decodable {
        let id: String?
        let post_id: String?
    }

    struct GraphErrorEnvelope: Decodable {
        struct GraphError: Decodable {
            let message: String
            let type: String?
            let code: Int?
            let error_subcode: Int?
        }
        let error: GraphError
    }

    enum APIError: LocalizedError {
        case invalidConfiguration
        case invalidResponse
        case graph(String)

        var errorDescription: String? {
            switch self {
            case .invalidConfiguration:
                return "Page ID, Page Access Token and a valid Graph API version (for example v26.0) are required."
            case .invalidResponse:
                return "Facebook returned an unreadable response."
            case .graph(let message):
                return message
            }
        }
    }

    private var baseURL: URL? {
        guard Self.isValidGraphVersion(graphVersion) else { return nil }
        return URL(string: "https://graph.facebook.com/\(graphVersion)")
    }

    // Ephemeral networking avoids persistent cookies, URL cache and disk-backed response caching.
    private var session: URLSession {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 180
        configuration.waitsForConnectivity = true
        configuration.httpAdditionalHeaders = [
            "Accept": "application/json"
        ]
        return URLSession(configuration: configuration)
    }

    func validatePage() async throws -> PageInfo {
        try validateConfiguration()
        guard let baseURL else { throw APIError.invalidConfiguration }

        var components = URLComponents(
            url: baseURL.appendingPathComponent(pageID),
            resolvingAgainstBaseURL: false
        )!
        components.queryItems = [
            URLQueryItem(name: "fields", value: "id,name")
        ]
        guard let url = components.url else { throw APIError.invalidConfiguration }

        var request = authorizedRequest(url: url)
        request.httpMethod = "GET"

        let (data, response) = try await session.data(for: request)
        try validateHTTP(response: response, data: data)
        return try JSONDecoder().decode(PageInfo.self, from: data)
    }

    func scheduleText(caption: String, date: Date) async throws -> String? {
        try validateConfiguration()
        guard let baseURL else { throw APIError.invalidConfiguration }

        let url = baseURL.appendingPathComponent(pageID).appendingPathComponent("feed")
        var request = authorizedRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = formEncoded([
            "message": caption,
            "published": "false",
            "scheduled_publish_time": String(Int(date.timeIntervalSince1970))
        ])

        let (data, response) = try await session.data(for: request)
        try validateHTTP(response: response, data: data)
        let decoded = try JSONDecoder().decode(PublishResponse.self, from: data)
        return decoded.post_id ?? decoded.id
    }

    func schedulePhoto(imageData: Data, caption: String, date: Date) async throws -> String? {
        try validateConfiguration()
        guard let baseURL else { throw APIError.invalidConfiguration }

        let url = baseURL.appendingPathComponent(pageID).appendingPathComponent("photos")
        let boundary = "Boundary-\(UUID().uuidString)"
        var request = authorizedRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 120
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        body.appendMultipartField(name: "caption", value: caption, boundary: boundary)
        body.appendMultipartField(name: "published", value: "false", boundary: boundary)
        body.appendMultipartField(name: "scheduled_publish_time", value: String(Int(date.timeIntervalSince1970)), boundary: boundary)
        body.appendMultipartFile(name: "source", filename: "photo.jpg", mimeType: "image/jpeg", fileData: imageData, boundary: boundary)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        let (data, response) = try await session.data(for: request)
        try validateHTTP(response: response, data: data)
        let decoded = try JSONDecoder().decode(PublishResponse.self, from: data)
        return decoded.post_id ?? decoded.id
    }

    private func authorizedRequest(url: URL) -> URLRequest {
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
        request.setValue("Bearer \(pageToken)", forHTTPHeaderField: "Authorization")
        request.setValue("no-store", forHTTPHeaderField: "Cache-Control")
        request.setValue("no-cache", forHTTPHeaderField: "Pragma")
        return request
    }

    private func validateConfiguration() throws {
        let trimmedPageID = pageID.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedToken = pageToken.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedPageID.isEmpty,
              trimmedPageID.allSatisfy({ $0.isNumber }),
              !trimmedToken.isEmpty,
              Self.isValidGraphVersion(graphVersion) else {
            throw APIError.invalidConfiguration
        }
    }

    private static func isValidGraphVersion(_ value: String) -> Bool {
        value.range(of: #"^v[0-9]{1,3}\.[0-9]{1,2}$"#, options: .regularExpression) != nil
    }

    private func validateHTTP(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { throw APIError.invalidResponse }
        if (200...299).contains(http.statusCode) { return }

        if let envelope = try? JSONDecoder().decode(GraphErrorEnvelope.self, from: data) {
            throw APIError.graph(Self.sanitizedError(envelope.error.message))
        }

        // Do not surface an arbitrary raw server body because it may contain sensitive request context.
        throw APIError.graph("Facebook request failed (HTTP \(http.statusCode)).")
    }

    private static func sanitizedError(_ message: String) -> String {
        let singleLine = message.replacingOccurrences(of: "\n", with: " ")
        return String(singleLine.prefix(500))
    }

    private func formEncoded(_ values: [String: String]) -> Data? {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-._~"))
        let string = values.map { key, value in
            let k = key.addingPercentEncoding(withAllowedCharacters: allowed) ?? key
            let v = value.addingPercentEncoding(withAllowedCharacters: allowed) ?? value
            return "\(k)=\(v)"
        }.joined(separator: "&")
        return string.data(using: .utf8)
    }
}

private extension Data {
    mutating func appendMultipartField(name: String, value: String, boundary: String) {
        append("--\(boundary)\r\n".data(using: .utf8)!)
        append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
        append("\(value)\r\n".data(using: .utf8)!)
    }

    mutating func appendMultipartFile(name: String, filename: String, mimeType: String, fileData: Data, boundary: String) {
        append("--\(boundary)\r\n".data(using: .utf8)!)
        append("Content-Disposition: form-data; name=\"\(name)\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
        append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        append(fileData)
        append("\r\n".data(using: .utf8)!)
    }
}
