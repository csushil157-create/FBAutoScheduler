import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            BatchView()
                .tabItem { Label("Batch", systemImage: "rectangle.stack.badge.plus") }
            ComposeView()
                .tabItem { Label("Single", systemImage: "calendar.badge.plus") }
            HistoryView()
                .tabItem { Label("History", systemImage: "clock.arrow.circlepath") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
    }
}
