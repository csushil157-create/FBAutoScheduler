import Foundation

struct ScheduledRecord: Identifiable, Codable, Equatable {
    enum Status: String, Codable {
        case scheduled = "Scheduled"
        case failed = "Failed"
    }

    let id: UUID
    let createdAt: Date
    let scheduledFor: Date
    let caption: String
    let mediaType: String
    let facebookPostID: String?
    let status: Status
    let errorMessage: String?
}

@MainActor
final class ScheduleHistory: ObservableObject {
    @Published private(set) var records: [ScheduledRecord] = [] {
        didSet { ProtectedHistoryStore.save(records) }
    }

    private let legacyKey = "scheduleHistory.v1"

    init() {
        records = ProtectedHistoryStore.load()
        migrateLegacyHistoryIfNeeded()
    }

    func add(_ record: ScheduledRecord) {
        records.insert(record, at: 0)
    }

    func delete(at offsets: IndexSet) {
        for index in offsets.sorted(by: >) {
            guard records.indices.contains(index) else { continue }
            records.remove(at: index)
        }
    }

    func clear() {
        records.removeAll()
        ProtectedHistoryStore.clear()
        UserDefaults.standard.removeObject(forKey: legacyKey)
    }

    private func migrateLegacyHistoryIfNeeded() {
        guard records.isEmpty,
              let oldData = UserDefaults.standard.data(forKey: legacyKey),
              let oldRecords = try? JSONDecoder().decode([ScheduledRecord].self, from: oldData) else {
            UserDefaults.standard.removeObject(forKey: legacyKey)
            return
        }

        records = oldRecords
        UserDefaults.standard.removeObject(forKey: legacyKey)
    }
}
