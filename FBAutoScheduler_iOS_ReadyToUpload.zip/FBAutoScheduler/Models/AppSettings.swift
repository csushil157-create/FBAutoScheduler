import Foundation

@MainActor
final class AppSettings: ObservableObject {
    @Published var pageID: String {
        didSet { UserDefaults.standard.set(pageID, forKey: "pageID") }
    }
    @Published var graphVersion: String {
        didSet { UserDefaults.standard.set(graphVersion, forKey: "graphVersion") }
    }
    @Published var pageToken: String = ""

    init() {
        self.pageID = UserDefaults.standard.string(forKey: "pageID") ?? ""
        self.graphVersion = UserDefaults.standard.string(forKey: "graphVersion") ?? "v23.0"
        self.pageToken = KeychainStore.load(key: "facebookPageToken") ?? ""
    }

    func saveToken() throws {
        try KeychainStore.save(pageToken, key: "facebookPageToken")
    }

    func clearToken() throws {
        try KeychainStore.delete(key: "facebookPageToken")
        pageToken = ""
    }
}
