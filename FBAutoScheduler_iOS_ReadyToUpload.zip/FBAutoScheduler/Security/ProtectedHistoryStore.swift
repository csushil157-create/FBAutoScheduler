import Foundation

enum ProtectedHistoryStore {
    private static let filename = "schedule-history-v2.json"

    private static var fileURL: URL? {
        guard let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return nil
        }
        let folder = base.appendingPathComponent("FBAutoScheduler", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            return folder.appendingPathComponent(filename)
        } catch {
            return nil
        }
    }

    static func load() -> [ScheduledRecord] {
        guard let url = fileURL,
              let data = try? Data(contentsOf: url),
              let records = try? JSONDecoder().decode([ScheduledRecord].self, from: data) else {
            return []
        }
        return records
    }

    static func save(_ records: [ScheduledRecord]) {
        guard let url = fileURL,
              let data = try? JSONEncoder().encode(records) else { return }

        // Complete file protection keeps persisted captions/history unavailable while the device is locked.
        try? data.write(to: url, options: [.atomic, .completeFileProtection])
    }

    static func clear() {
        guard let url = fileURL else { return }
        try? FileManager.default.removeItem(at: url)
    }
}
