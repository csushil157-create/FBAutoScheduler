import SwiftUI

@main
struct FBAutoSchedulerApp: App {
    @StateObject private var settings = AppSettings()
    @StateObject private var history = ScheduleHistory()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .environmentObject(history)
        }
    }
}
