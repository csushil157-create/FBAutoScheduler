import SwiftUI

struct HistoryView: View {
    @EnvironmentObject private var history: ScheduleHistory

    var body: some View {
        NavigationStack {
            List {
                if history.records.isEmpty {
                    ContentUnavailableView("No scheduled posts yet", systemImage: "calendar.badge.clock")
                } else {
                    ForEach(history.records) { record in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text(record.mediaType).font(.headline)
                                Spacer()
                                Text(record.status.rawValue)
                                    .font(.caption.bold())
                            }
                            Text(record.caption)
                                .lineLimit(3)
                            Text(record.scheduledFor.formatted(date: .abbreviated, time: .shortened))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            if let id = record.facebookPostID {
                                Text("ID: \(id)").font(.caption2).foregroundStyle(.secondary)
                            }
                            if let error = record.errorMessage {
                                Text(error).font(.caption).foregroundStyle(.red)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .onDelete(perform: history.delete)
                }
            }
            .navigationTitle("History")
            .toolbar {
                if !history.records.isEmpty {
                    Button("Clear") { history.clear() }
                }
            }
        }
    }
}
