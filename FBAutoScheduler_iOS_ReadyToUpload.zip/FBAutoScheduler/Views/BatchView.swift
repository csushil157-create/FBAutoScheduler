import SwiftUI
import PhotosUI
import UIKit

struct BatchView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var history: ScheduleHistory

    @State private var pickerItems: [PhotosPickerItem] = []
    @State private var imageData: [Data] = []
    @State private var firstDate = Date().addingTimeInterval(15 * 60)
    @State private var gapMinutes = 40
    @State private var sameCaption = true
    @State private var captionsText = ""
    @State private var isScheduling = false
    @State private var progressText = ""
    @State private var alertText = ""
    @State private var showAlert = false

    var body: some View {
        NavigationStack {
            Form {
                Section("1. Photos") {
                    PhotosPicker(selection: $pickerItems, maxSelectionCount: 30, matching: .images) {
                        Label("Choose up to 30 photos", systemImage: "photo.on.rectangle.angled")
                    }
                    .onChange(of: pickerItems) { _, newItems in
                        Task { await loadImages(newItems) }
                    }
                    Text("Selected: \(imageData.count)")
                        .foregroundStyle(.secondary)
                }

                Section("2. Captions") {
                    Toggle("Use same caption for all photos", isOn: $sameCaption)
                    TextEditor(text: $captionsText)
                        .frame(minHeight: 150)
                    if sameCaption {
                        Text("This caption will be used for every selected photo.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        Text("Paste one caption per photo. Put a line containing only --- between captions. Captions found: \(parsedCaptions.count)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Section("3. Timing") {
                    DatePicker("First post", selection: $firstDate, in: Date()..., displayedComponents: [.date, .hourAndMinute])
                    Stepper("Gap: \(gapMinutes) minutes", value: $gapMinutes, in: 5...360, step: 5)
                    if !imageData.isEmpty {
                        Text("Last post: \(lastPostDate.formatted(date: .abbreviated, time: .shortened))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                Section {
                    Button {
                        Task { await scheduleBatch() }
                    } label: {
                        HStack {
                            Spacer()
                            if isScheduling { ProgressView().padding(.trailing, 8) }
                            Text(isScheduling ? progressText : "Schedule Batch on Facebook")
                            Spacer()
                        }
                    }
                    .disabled(!canSchedule || isScheduling)
                } footer: {
                    Text("Posts are submitted to Facebook one by one with future publish times. The app does not need to stay open after Facebook accepts them.")
                }
            }
            .navigationTitle("Batch Scheduler")
            .alert("Batch Scheduler", isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(alertText)
            }
        }
    }

    private var parsedCaptions: [String] {
        captionsText
            .components(separatedBy: "\n---\n")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    private var canSchedule: Bool {
        guard !imageData.isEmpty else { return false }
        if sameCaption {
            return !captionsText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        return parsedCaptions.count == imageData.count
    }

    private var lastPostDate: Date {
        firstDate.addingTimeInterval(TimeInterval(max(0, imageData.count - 1) * gapMinutes * 60))
    }

    private func loadImages(_ items: [PhotosPickerItem]) async {
        var loaded: [Data] = []
        for item in items {
            do {
                guard let original = try await item.loadTransferable(type: Data.self),
                      let image = UIImage(data: original),
                      let jpg = image.jpegData(compressionQuality: 0.90) else { continue }
                loaded.append(jpg)
            } catch {
                // Skip unreadable items; the selected/loaded count makes this visible.
            }
        }
        imageData = loaded
    }

    private func scheduleBatch() async {
        guard canSchedule else { return }
        isScheduling = true
        var successes = 0
        var failures = 0
        var firstError: String?

        do { try settings.saveToken() } catch {
            alertText = error.localizedDescription
            showAlert = true
            isScheduling = false
            return
        }

        let api = FacebookAPI(pageID: settings.pageID.trimmingCharacters(in: .whitespacesAndNewlines),
                              pageToken: settings.pageToken.trimmingCharacters(in: .whitespacesAndNewlines),
                              graphVersion: settings.graphVersion.trimmingCharacters(in: .whitespacesAndNewlines))
        let captions = sameCaption ? Array(repeating: captionsText.trimmingCharacters(in: .whitespacesAndNewlines), count: imageData.count) : parsedCaptions

        for index in imageData.indices {
            progressText = "Scheduling \(index + 1)/\(imageData.count)…"
            let date = firstDate.addingTimeInterval(TimeInterval(index * gapMinutes * 60))
            let caption = captions[index]
            do {
                let postID = try await api.schedulePhoto(imageData: imageData[index], caption: caption, date: date)
                history.add(ScheduledRecord(id: UUID(), createdAt: Date(), scheduledFor: date,
                                            caption: caption, mediaType: "Photo", facebookPostID: postID,
                                            status: .scheduled, errorMessage: nil))
                successes += 1
            } catch {
                let errorText = error.localizedDescription
                firstError = firstError ?? errorText
                history.add(ScheduledRecord(id: UUID(), createdAt: Date(), scheduledFor: date,
                                            caption: caption, mediaType: "Photo", facebookPostID: nil,
                                            status: .failed, errorMessage: errorText))
                failures += 1
            }
        }

        isScheduling = false
        progressText = ""
        if failures == 0 {
            alertText = "All \(successes) posts were accepted for scheduling by Facebook."
            pickerItems = []
            imageData = []
            captionsText = ""
        } else {
            alertText = "Scheduled: \(successes). Failed: \(failures). First error: \(firstError ?? "Unknown error")"
        }
        showAlert = true
    }
}
