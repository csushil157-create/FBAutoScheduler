import SwiftUI
import PhotosUI
import UIKit

struct ComposeView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var history: ScheduleHistory

    @State private var caption = ""
    @State private var selectedDate = Date().addingTimeInterval(15 * 60)
    @State private var pickerItem: PhotosPickerItem?
    @State private var imageData: Data?
    @State private var previewImage: UIImage?
    @State private var isSending = false
    @State private var message: String?
    @State private var showAlert = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Post") {
                    PhotosPicker(selection: $pickerItem, matching: .images) {
                        Label(imageData == nil ? "Choose photo (optional)" : "Change photo", systemImage: "photo")
                    }
                    .onChange(of: pickerItem) { _, newItem in
                        Task { await loadImage(from: newItem) }
                    }

                    if let previewImage {
                        Image(uiImage: previewImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 220)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    }

                    TextEditor(text: $caption)
                        .frame(minHeight: 130)

                    DatePicker("Publish at", selection: $selectedDate, in: Date()..., displayedComponents: [.date, .hourAndMinute])
                }

                Section {
                    Button {
                        Task { await schedule() }
                    } label: {
                        HStack {
                            Spacer()
                            if isSending { ProgressView().padding(.trailing, 6) }
                            Text(isSending ? "Scheduling…" : "Schedule on Facebook")
                            Spacer()
                        }
                    }
                    .disabled(isSending || caption.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                } footer: {
                    Text("The app submits the future publish time to Facebook. Facebook enforces the allowed scheduling window and Page/API permissions.")
                }
            }
            .navigationTitle("FB Scheduler")
            .alert("FB Auto Scheduler", isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(message ?? "")
            }
        }
    }

    private func loadImage(from item: PhotosPickerItem?) async {
        guard let item else {
            imageData = nil
            previewImage = nil
            return
        }
        do {
            guard let originalData = try await item.loadTransferable(type: Data.self),
                  let uiImage = UIImage(data: originalData) else { return }
            previewImage = uiImage
            imageData = uiImage.jpegData(compressionQuality: 0.92)
        } catch {
            message = error.localizedDescription
            showAlert = true
        }
    }

    private func schedule() async {
        isSending = true
        defer { isSending = false }

        do {
            try settings.saveToken()
            let api = FacebookAPI(pageID: settings.pageID.trimmingCharacters(in: .whitespacesAndNewlines),
                                  pageToken: settings.pageToken.trimmingCharacters(in: .whitespacesAndNewlines),
                                  graphVersion: settings.graphVersion.trimmingCharacters(in: .whitespacesAndNewlines))
            let postID: String?
            let mediaType: String
            if let imageData {
                postID = try await api.schedulePhoto(imageData: imageData, caption: caption, date: selectedDate)
                mediaType = "Photo"
            } else {
                postID = try await api.scheduleText(caption: caption, date: selectedDate)
                mediaType = "Text"
            }

            history.add(ScheduledRecord(id: UUID(), createdAt: Date(), scheduledFor: selectedDate,
                                        caption: caption, mediaType: mediaType, facebookPostID: postID,
                                        status: .scheduled, errorMessage: nil))
            message = postID.map { "Scheduled successfully. Facebook ID: \($0)" } ?? "Scheduled successfully."
            showAlert = true
            caption = ""
            pickerItem = nil
            imageData = nil
            previewImage = nil
            selectedDate = Date().addingTimeInterval(15 * 60)
        } catch {
            history.add(ScheduledRecord(id: UUID(), createdAt: Date(), scheduledFor: selectedDate,
                                        caption: caption, mediaType: imageData == nil ? "Text" : "Photo",
                                        facebookPostID: nil, status: .failed, errorMessage: error.localizedDescription))
            message = error.localizedDescription
            showAlert = true
        }
    }
}
