import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @State private var isChecking = false
    @State private var result = ""
    @State private var showAlert = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Facebook Page") {
                    TextField("Page ID", text: $settings.pageID)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.numberPad)
                    SecureField("Page Access Token", text: $settings.pageToken)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Graph API version (example: v23.0)", text: $settings.graphVersion)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }

                Section {
                    Button(isChecking ? "Checking…" : "Test Page Connection") {
                        Task { await testConnection() }
                    }
                    .disabled(isChecking)

                    Button("Save Token to Keychain") {
                        do {
                            try settings.saveToken()
                            result = "Token saved securely in Keychain."
                        } catch {
                            result = error.localizedDescription
                        }
                        showAlert = true
                    }

                    Button("Remove Saved Token", role: .destructive) {
                        do {
                            try settings.clearToken()
                            result = "Saved token removed."
                        } catch {
                            result = error.localizedDescription
                        }
                        showAlert = true
                    }
                }

                Section("Token requirements") {
                    Text("Use a Page access token that can manage posts for the Page. Depending on your Meta app setup, permissions/app review may be required.")
                    Text("Do not share the token in chats, screenshots, or public repositories.")
                }
            }
            .navigationTitle("Settings")
            .alert("Connection", isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(result)
            }
        }
    }

    private func testConnection() async {
        isChecking = true
        defer { isChecking = false }
        do {
            try settings.saveToken()
            let api = FacebookAPI(pageID: settings.pageID.trimmingCharacters(in: .whitespacesAndNewlines),
                                  pageToken: settings.pageToken.trimmingCharacters(in: .whitespacesAndNewlines),
                                  graphVersion: settings.graphVersion.trimmingCharacters(in: .whitespacesAndNewlines))
            let page = try await api.validatePage()
            result = "Connected: \(page.name) (\(page.id))"
        } catch {
            result = error.localizedDescription
        }
        showAlert = true
    }
}
