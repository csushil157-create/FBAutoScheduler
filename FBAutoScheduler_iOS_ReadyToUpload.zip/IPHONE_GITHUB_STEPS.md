# iPhone GitHub build steps

1. Open https://github.com/new and create a **Private** repository named `FBAutoScheduler`. Do not initialize it with a README.
2. Upload the project files from this folder so that `project.yml`, `FBAutoScheduler/`, and `.github/workflows/build.yml` are at the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build iOS IPA** and tap **Run workflow** if a build is not already running.
5. When the run is green, open it and download the **FBAutoScheduler-unsigned** artifact.
6. The artifact ZIP contains `FBAutoScheduler-unsigned.ipa`. It is unsigned and must be signed/resigned with your normal sideloading method before installation.

Never put your Facebook Page access token in GitHub. Enter it only inside the installed app.
